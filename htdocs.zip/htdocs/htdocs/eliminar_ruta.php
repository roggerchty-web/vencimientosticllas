<?php
require_once __DIR__ . '/auth.php';
require_edit();
verify_csrf();
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: rutas.php');
    exit;
}

$id = $_POST['id'] ?? '';

if ($id !== '') {
    $stmt = $pdo->prepare('DELETE FROM rutas WHERE id = :id');
    $stmt->execute(['id' => $id]);
}

header('Location: rutas.php');
exit;
