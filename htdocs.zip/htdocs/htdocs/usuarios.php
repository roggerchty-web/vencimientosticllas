<?php
require_once __DIR__ . '/auth.php';
require_admin();
$mensaje=''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $accion=$_POST['accion']??'';
    try {
        if ($accion==='guardar') {
            $id=(int)($_POST['id']??0); $nombre=trim($_POST['nombre']??''); $usuario=trim($_POST['usuario']??''); $password=$_POST['password']??''; $rol=(int)($_POST['rol_id']??0); $estado=$_POST['estado']??'ACTIVO';
            if($nombre===''||$usuario===''||$rol<=0) throw new Exception('Completa los campos obligatorios.');
            if($id){
                $sql='UPDATE usuarios SET nombre=:nombre, usuario=:usuario, rol_id=:rol, estado=:estado'.($password!==''?', password_hash=:hash':'').' WHERE id=:id';
                $p=['nombre'=>$nombre,'usuario'=>$usuario,'rol'=>$rol,'estado'=>$estado,'id'=>$id]; if($password!=='')$p['hash']=password_hash($password,PASSWORD_DEFAULT);
                $pdo->prepare($sql)->execute($p);
            }else{
                if($password==='') throw new Exception('La contraseña es obligatoria para un usuario nuevo.');
                $pdo->prepare('INSERT INTO usuarios(nombre,usuario,password_hash,rol_id,estado) VALUES(:nombre,:usuario,:hash,:rol,:estado)')->execute(['nombre'=>$nombre,'usuario'=>$usuario,'hash'=>password_hash($password,PASSWORD_DEFAULT),'rol'=>$rol,'estado'=>$estado]);
            }
            $mensaje='Usuario guardado correctamente.';
        } elseif($accion==='eliminar') {
            $id=(int)($_POST['id']??0); if($id===(int)$_SESSION['usuario_id']) throw new Exception('No puedes eliminar tu propio usuario.');
            $pdo->prepare('DELETE FROM usuarios WHERE id=?')->execute([$id]); $mensaje='Usuario eliminado.';
        }
    } catch(Throwable $e){ $error=$e instanceof PDOException && $e->getCode()==='23000' ? 'Ese nombre de usuario ya existe.' : $e->getMessage(); }
}
$roles=$pdo->query('SELECT id,nombre,descripcion FROM roles ORDER BY id')->fetchAll();
$usuarios=$pdo->query('SELECT u.*,r.nombre rol FROM usuarios u JOIN roles r ON r.id=u.rol_id ORDER BY u.nombre')->fetchAll();
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Usuarios - TICLLAS</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:#f4f7fb;color:#17335f}.top{background:#fff;border-bottom:5px solid #d71920;padding:15px 25px}.top a{text-decoration:none}.box{background:#fff;border:1px solid #dbe5f2;border-radius:10px;padding:20px;margin-top:20px}.badge-activo{background:#dff4e8;color:#08733b}.badge-inactivo{background:#f8d7da;color:#842029}</style></head><body><header class="top"><strong style="font-size:22px;color:#123f91">TICLLAS — Usuarios y roles</strong><span class="float-end"><a href="index.php">Volver al sistema</a> · <a href="logout.php">Cerrar sesión</a></span></header><main class="container py-3"><?php if($mensaje):?><div class="alert alert-success"><?=htmlspecialchars($mensaje)?></div><?php endif;?><?php if($error):?><div class="alert alert-danger"><?=htmlspecialchars($error)?></div><?php endif;?><div class="box"><h4>Crear / editar usuario</h4><form method="post" class="row g-3"><input type="hidden" name="accion" value="guardar"><?=csrf_field()?><!-- El administrador puede usar este formulario para gestionar accesos --><div class="col-md-3"><label>Nombre</label><input name="nombre" class="form-control" required></div><div class="col-md-3"><label>Usuario</label><input name="usuario" class="form-control" required></div><div class="col-md-2"><label>Contraseña</label><input type="password" name="password" class="form-control" placeholder="Nueva si edita"></div><div class="col-md-2"><label>Rol</label><select name="rol_id" class="form-select" required><?php foreach($roles as $r):?><option value="<?=$r['id']?>"><?=htmlspecialchars($r['nombre'])?></option><?php endforeach;?></select></div><div class="col-md-2"><label>Estado</label><select name="estado" class="form-select"><option>ACTIVO</option><option>INACTIVO</option></select></div><div class="col-12"><button class="btn btn-primary">Guardar usuario</button></div></form></div><div class="box"><h4>Usuarios registrados</h4><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Nombre</th><th>Usuario</th><th>Rol</th><th>Estado</th><th>Último acceso</th><th></th></tr></thead><tbody><?php foreach($usuarios as $u):?><tr><td><?=htmlspecialchars($u['nombre'])?></td><td><?=htmlspecialchars($u['usuario'])?></td><td><?=htmlspecialchars($u['rol'])?></td><td><span class="badge <?= $u['estado']==='ACTIVO'?'badge-activo':'badge-inactivo' ?>"><?=htmlspecialchars($u['estado'])?></span></td><td><?=htmlspecialchars($u['ultimo_acceso']?:'Nunca')?></td><td><?php if((int)$u['id']!==(int)$_SESSION['usuario_id']):?><form method="post" onsubmit="return confirm('¿Eliminar este usuario?')"><input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?=$u['id']?>"><?=csrf_field()?><button class="btn btn-sm btn-outline-danger">Eliminar</button></form><?php endif;?></td></tr><?php endforeach;?></tbody></table></div></div></main></body></html>
