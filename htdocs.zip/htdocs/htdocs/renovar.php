<?php
require_once __DIR__ . '/auth.php';
require_edit();
verify_csrf();
require 'config.php';
require 'functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$tipo = $_POST['tipo'] ?? '';
$id = (int) ($_POST['id'] ?? 0);
$meses = (int) ($_POST['meses'] ?? 12);
$meses = max(1, min($meses, 120));

// Solo se permite renovar estos tres documentos.
$tablas = [
    'rt'   => 'revisiones_tecnicas',
    'soat' => 'soats',
    'tc'   => 'tarjetas_circulacion',
];

if (!isset($tablas[$tipo]) || $id <= 0) {
    header('Location: index.php?error=renovacion_invalida');
    exit;
}

$tabla = $tablas[$tipo];

try {
    $pdo->beginTransaction();

    // Obtiene la fecha de vencimiento vigente del registro seleccionado.
    $stmt = $pdo->prepare("SELECT vigente_hasta FROM {$tabla} WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $fechaAnterior = $stmt->fetchColumn();

    if (!$fechaAnterior) {
        throw new RuntimeException('sin_fecha');
    }

    // Renovación automática: comienza el día del vencimiento anterior
    // y termina después de la cantidad de meses indicada.
    $nuevaFechaInicio = $fechaAnterior;
    $nuevaFechaFin = sumarMeses($fechaAnterior, $meses);

    $stmt = $pdo->prepare(
        "UPDATE {$tabla}
         SET vigente_desde = ?, vigente_hasta = ?, actualizado_en = CURRENT_TIMESTAMP
         WHERE id = ?"
    );
    $stmt->execute([$nuevaFechaInicio, $nuevaFechaFin, $id]);

    $pdo->commit();
    header('Location: index.php?ok=renovado');
    exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    $codigo = $e->getMessage() === 'sin_fecha' ? 'renovacion_sin_fecha' : 'renovacion_error';
    header('Location: index.php?error=' . $codigo);
    exit;
}
