<?php
require_once __DIR__ . '/auth.php';
require_edit();
verify_csrf();
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: rutas.php');
    exit;
}

$id = $_POST['id'] ?? '';
$nombre = trim($_POST['nombre'] ?? '');
$inauguracion = $_POST['fecha_inauguracion'] ?: null;
$vencimiento  = $_POST['fecha_vencimiento'] ?: null;

if ($nombre === '') {
    header('Location: rutas.php?error=nombre_vacio');
    exit;
}

if ($id !== '') {
    $sql = 'UPDATE rutas
            SET nombre = :nombre, fecha_inauguracion = :inauguracion, fecha_vencimiento = :vencimiento
            WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'nombre' => $nombre,
        'inauguracion' => $inauguracion,
        'vencimiento' => $vencimiento,
        'id' => $id,
    ]);
} else {
    $sql = 'INSERT INTO rutas (nombre, fecha_inauguracion, fecha_vencimiento)
            VALUES (:nombre, :inauguracion, :vencimiento)';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'nombre' => $nombre,
        'inauguracion' => $inauguracion,
        'vencimiento' => $vencimiento,
    ]);
}

header('Location: rutas.php');
exit;
