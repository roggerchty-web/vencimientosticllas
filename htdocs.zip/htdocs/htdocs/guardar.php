<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$id    = (int) ($_POST['id'] ?? 0);
$placa = strtoupper(trim($_POST['placa'] ?? ''));

if (!$placa) {
    header('Location: index.php?error=placa_vacia');
    exit;
}

$socio       = trim($_POST['socio'] ?? '');
$responsable = trim($_POST['responsable'] ?? '');

try {
    $pdo->beginTransaction();

    // --- Socio: si escribieron un nombre, lo busca o lo crea ---
    if ($socio) {
        $stmt = $pdo->prepare('INSERT INTO socios (nombre) VALUES (?) ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)');
        $stmt->execute([$socio]);
        $socioId = (int) $pdo->lastInsertId();
    } else {
        $socioId = null;
    }

    // --- Responsable: igual, pero siempre ligado a ese socio ---
    if ($responsable && $socioId) {
        $stmt = $pdo->prepare('INSERT INTO responsables (socio_id, nombre) VALUES (?, ?) ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)');
        $stmt->execute([$socioId, $responsable]);
        $responsableId = (int) $pdo->lastInsertId();
    } else {
        $responsableId = null;
    }

    // --- Vehículo: actualizar si ya existe, insertar si es nuevo ---
    if ($id) {
        $stmt = $pdo->prepare('SELECT id FROM vehiculos WHERE placa = ? AND id <> ?');
        $stmt->execute([$placa, $id]);
        if ($stmt->fetch()) {
            throw new Exception('placa_duplicada');
        }
        $stmt = $pdo->prepare('UPDATE vehiculos SET placa = ?, socio_id = ?, responsable_id = ? WHERE id = ?');
        $stmt->execute([$placa, $socioId, $responsableId, $id]);
    } else {
        $stmt = $pdo->prepare('SELECT id FROM vehiculos WHERE placa = ?');
        $stmt->execute([$placa]);
        if ($stmt->fetch()) {
            throw new Exception('placa_duplicada');
        }
        $stmt = $pdo->prepare('INSERT INTO vehiculos (placa, socio_id, responsable_id) VALUES (?, ?, ?)');
        $stmt->execute([$placa, $socioId, $responsableId]);
        $id = (int) $pdo->lastInsertId();
    }

    // --- Revisión técnica: actualiza el registro más reciente, o crea uno si no existe ---
    $rt = [
        'vehiculo_id'          => $id,
        'numero_certificado'   => trim($_POST['rt_certificado'] ?? '') ?: null,
        'vigente_desde'        => $_POST['rt_vigente_desde'] ?: null,
        'vigente_hasta'        => $_POST['rt_vigente_hasta'] ?: null,
        'resultado_inspeccion' => $_POST['rt_resultado'] ?: null,
    ];
    $stmt = $pdo->prepare('SELECT id FROM revisiones_tecnicas WHERE vehiculo_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$id]);
    $rtId = $stmt->fetchColumn();

    if ($rtId) {
        $stmt = $pdo->prepare('UPDATE revisiones_tecnicas
                                SET numero_certificado = ?, vigente_desde = ?, vigente_hasta = ?, resultado_inspeccion = ?
                                WHERE id = ?');
        $stmt->execute([$rt['numero_certificado'], $rt['vigente_desde'], $rt['vigente_hasta'], $rt['resultado_inspeccion'], $rtId]);
    } elseif (array_filter($rt)) {
        $stmt = $pdo->prepare('INSERT INTO revisiones_tecnicas (vehiculo_id, numero_certificado, vigente_desde, vigente_hasta, resultado_inspeccion)
                                VALUES (?, ?, ?, ?, ?)');
        $stmt->execute(array_values($rt));
    }

    // --- SOAT (formulario compacto) ---
    $soat = [
        'vigente_hasta' => $_POST['soat_vigente_hasta'] ?: null,
        'uso'           => trim($_POST['soat_uso'] ?? '') ?: null,
        'clase'         => trim($_POST['soat_clase'] ?? '') ?: null,
    ];
    $stmt = $pdo->prepare('SELECT id FROM soats WHERE vehiculo_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$id]);
    $soatId = $stmt->fetchColumn();
    if ($soatId) {
        $stmt = $pdo->prepare('UPDATE soats SET vigente_hasta = ?, uso = ?, clase = ? WHERE id = ?');
        $stmt->execute(array_merge(array_values($soat), [$soatId]));
    } elseif (array_filter($soat)) {
        $stmt = $pdo->prepare('INSERT INTO soats (vehiculo_id, vigente_hasta, uso, clase) VALUES (?, ?, ?, ?)');
        $stmt->execute(array_merge([$id], array_values($soat)));
    }

    // --- Tarjeta Única de Circulación ---
    $tc = [
        'numero'            => trim($_POST['tc_numero'] ?? '') ?: null,
        'vigente_desde'     => $_POST['tc_vigente_desde'] ?: null,
        'vigente_hasta'     => $_POST['tc_vigente_hasta'] ?: null,
        'razon_social'      => trim($_POST['tc_razon_social'] ?? '') ?: null,
        'ruc'               => trim($_POST['tc_ruc'] ?? '') ?: null,
        'partida_registral' => trim($_POST['tc_partida_registral'] ?? '') ?: null,
        'modalidad_servicio'=> trim($_POST['tc_modalidad_servicio'] ?? '') ?: null,
        'documento_sustento'=> trim($_POST['tc_documento_sustento'] ?? '') ?: null,
    ];
    $stmt = $pdo->prepare('SELECT id FROM tarjetas_circulacion WHERE vehiculo_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$id]);
    $tcId = $stmt->fetchColumn();
    if ($tcId) {
        $stmt = $pdo->prepare('UPDATE tarjetas_circulacion SET numero=?, vigente_desde=?, vigente_hasta=?, razon_social=?, ruc=?, partida_registral=?, modalidad_servicio=?, documento_sustento=? WHERE id=?');
        $stmt->execute(array_merge(array_values($tc), [$tcId]));
    } elseif (array_filter($tc)) {
        $stmt = $pdo->prepare('INSERT INTO tarjetas_circulacion (vehiculo_id, numero, vigente_desde, vigente_hasta, razon_social, ruc, partida_registral, modalidad_servicio, documento_sustento) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute(array_merge([$id], array_values($tc)));
    }

    // --- Concesión / Ruta ---
    $rutaId = $_POST['ruta_id'] ? (int) $_POST['ruta_id'] : null;
    $cr = [
        'ruta_id'           => $rutaId,
        'numero_concesion'  => trim($_POST['cr_numero_concesion'] ?? '') ?: null,
        'vigente_desde'     => $_POST['cr_vigente_desde'] ?: null,
        'vigente_hasta'     => $_POST['cr_vigente_hasta'] ?: null,
        'observaciones'     => trim($_POST['cr_observaciones'] ?? '') ?: null,
    ];
    $stmt = $pdo->prepare('SELECT id FROM concesiones_rutas WHERE vehiculo_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$id]);
    $crId = $stmt->fetchColumn();

    if ($crId) {
        $stmt = $pdo->prepare('UPDATE concesiones_rutas SET ruta_id = ?, numero_concesion = ?, vigente_desde = ?, vigente_hasta = ?, observaciones = ? WHERE id = ?');
        $stmt->execute(array_merge(array_values($cr), [$crId]));
    } elseif (array_filter($cr)) {
        $stmt = $pdo->prepare('INSERT INTO concesiones_rutas (vehiculo_id, ruta_id, numero_concesion, vigente_desde, vigente_hasta, observaciones)
                                VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute(array_merge([$id], array_values($cr)));
    }

    $pdo->commit();
    header('Location: index.php?ok=1');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $error = $e->getMessage() === 'placa_duplicada' ? 'placa_duplicada' : 'guardar_error';
    header('Location: index.php?error=' . $error);
}
