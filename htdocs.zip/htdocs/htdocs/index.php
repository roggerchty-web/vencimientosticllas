<?php
require 'config.php';
require 'functions.php';

$buscar = trim($_GET['buscar'] ?? '');
$filtroAlerta = $_GET['alerta'] ?? '';
if (!in_array($filtroAlerta, ['vencidos', 'porvencer'], true)) {
    $filtroAlerta = '';
}

// --- Vehículos con el dato más reciente de cada documento (subconsultas) ---
$sql = "
    SELECT
        v.id, v.placa, v.socio_id, v.responsable_id, s.nombre AS socio, rp.nombre AS responsable,

        (SELECT rt.id FROM revisiones_tecnicas rt WHERE rt.vehiculo_id = v.id ORDER BY rt.id DESC LIMIT 1) AS rt_id,
        (SELECT rt.numero_certificado FROM revisiones_tecnicas rt WHERE rt.vehiculo_id = v.id ORDER BY rt.id DESC LIMIT 1) AS rt_certificado,
        (SELECT rt.vigente_desde      FROM revisiones_tecnicas rt WHERE rt.vehiculo_id = v.id ORDER BY rt.id DESC LIMIT 1) AS rt_vigente_desde,
        (SELECT rt.vigente_hasta      FROM revisiones_tecnicas rt WHERE rt.vehiculo_id = v.id ORDER BY rt.id DESC LIMIT 1) AS rt_vigente_hasta,
        (SELECT rt.resultado_inspeccion FROM revisiones_tecnicas rt WHERE rt.vehiculo_id = v.id ORDER BY rt.id DESC LIMIT 1) AS rt_resultado,

        (SELECT st.id FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_id,
        (SELECT st.compania         FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_compania,
        (SELECT st.vigente_desde    FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_vigente_desde,
        (SELECT st.vigente_hasta    FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_vigente_hasta,
        (SELECT st.certificado      FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_certificado,
        (SELECT st.uso              FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_uso,
        (SELECT st.clase            FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_clase,
        (SELECT st.tipo             FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_tipo,
        (SELECT st.fecha_creacion   FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_fecha_creacion,
        (SELECT st.fecha_anulacion  FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_fecha_anulacion,
        (SELECT st.control_policial FROM soats st WHERE st.vehiculo_id = v.id ORDER BY st.id DESC LIMIT 1) AS soat_control_policial,

        (SELECT tc.id FROM tarjetas_circulacion tc WHERE tc.vehiculo_id = v.id ORDER BY tc.id DESC LIMIT 1) AS tc_id,
        (SELECT tc.numero        FROM tarjetas_circulacion tc WHERE tc.vehiculo_id = v.id ORDER BY tc.id DESC LIMIT 1) AS tc_numero,
        (SELECT tc.vigente_desde FROM tarjetas_circulacion tc WHERE tc.vehiculo_id = v.id ORDER BY tc.id DESC LIMIT 1) AS tc_vigente_desde,
        (SELECT tc.vigente_hasta FROM tarjetas_circulacion tc WHERE tc.vehiculo_id = v.id ORDER BY tc.id DESC LIMIT 1) AS tc_vigente_hasta,
        (SELECT tc.observaciones FROM tarjetas_circulacion tc WHERE tc.vehiculo_id = v.id ORDER BY tc.id DESC LIMIT 1) AS tc_observaciones,

        (SELECT cr.id FROM concesiones_rutas cr WHERE cr.vehiculo_id = v.id ORDER BY cr.id DESC LIMIT 1) AS cr_id,
        (SELECT cr.ruta_id          FROM concesiones_rutas cr WHERE cr.vehiculo_id = v.id ORDER BY cr.id DESC LIMIT 1) AS ruta_id,
        (SELECT cr.numero_concesion FROM concesiones_rutas cr WHERE cr.vehiculo_id = v.id ORDER BY cr.id DESC LIMIT 1) AS cr_numero_concesion,
        (SELECT cr.vigente_desde    FROM concesiones_rutas cr WHERE cr.vehiculo_id = v.id ORDER BY cr.id DESC LIMIT 1) AS cr_vigente_desde,
        (SELECT cr.vigente_hasta    FROM concesiones_rutas cr WHERE cr.vehiculo_id = v.id ORDER BY cr.id DESC LIMIT 1) AS cr_vigente_hasta,
        (SELECT cr.observaciones    FROM concesiones_rutas cr WHERE cr.vehiculo_id = v.id ORDER BY cr.id DESC LIMIT 1) AS cr_observaciones,
        (SELECT ru.nombre FROM concesiones_rutas cr JOIN rutas ru ON ru.id = cr.ruta_id WHERE cr.vehiculo_id = v.id ORDER BY cr.id DESC LIMIT 1) AS ruta_nombre

    FROM vehiculos v
    LEFT JOIN socios s ON s.id = v.socio_id
    LEFT JOIN responsables rp ON rp.id = v.responsable_id
    ORDER BY s.nombre, rp.nombre, v.placa
";
$todos = $pdo->query($sql)->fetchAll();
$vehiculos = $todos;

if ($buscar !== '') {
    $q = strtoupper($buscar);
    $vehiculos = array_values(array_filter($vehiculos, function ($v) use ($q) {
        $texto = strtoupper(($v['placa'] ?? '') . ' ' . ($v['socio'] ?? '') . ' ' . ($v['responsable'] ?? ''));
        return str_contains($texto, $q);
    }));
}

// --- Selector Socio -> Responsable: las placas solo aparecen si eliges alguno de los dos ---
$socios = $pdo->query('SELECT * FROM socios ORDER BY nombre')->fetchAll();

$socioId = $_GET['socio_id'] ?? '';
$responsableId = $_GET['responsable_id'] ?? '';

$responsablesDelSocio = [];
if ($socioId !== '') {
    $stmt = $pdo->prepare('SELECT * FROM responsables WHERE socio_id = ? ORDER BY nombre');
    $stmt->execute([$socioId]);
    $responsablesDelSocio = $stmt->fetchAll();
}

$mostrarVehiculos = $buscar !== '' || $socioId !== '';

if ($socioId !== '') {
    $vehiculos = array_values(array_filter($vehiculos, fn($v) => (string) $v['socio_id'] === (string) $socioId));
}
if ($responsableId !== '') {
    $vehiculos = array_values(array_filter($vehiculos, fn($v) => (string) $v['responsable_id'] === (string) $responsableId));
}

// --- Contadores de la cabecera y notificaciones de "vence en 3 días" ---
$docs = [
    'rt_vigente_hasta'   => 'Revisión técnica',
    'soat_vigente_hasta' => 'SOAT',
    'tc_vigente_hasta'   => 'Tarjeta de circulación',
    'cr_vigente_hasta'   => 'Concesión / Ruta',
];

$alertas = [];
$vencidos = 0;
$por3 = 0;
$vigentes = 0;
$conDocs = 0;

foreach ($todos as $v) {
    $fechas = [$v['rt_vigente_hasta'], $v['soat_vigente_hasta'], $v['tc_vigente_hasta'], $v['cr_vigente_hasta']];
    $estados = array_map('estadoDocumento', $fechas);

    if (in_array('vencido', $estados, true)) {
        $vencidos++;
    } elseif (in_array('porvencer', $estados, true)) {
        $por3++;
    } elseif (in_array('vigente', $estados, true)) {
        $vigentes++;
    }
    if (array_filter($fechas)) {
        $conDocs++;
    }

    foreach ($docs as $campo => $nombreDoc) {
        $fecha = $v[$campo] ?? null;
        if (alerta3($fecha)) {
            $alertas[] = [
                'documento'   => $nombreDoc,
                'placa'       => $v['placa'],
                'socio'       => $v['socio'] ?: 'Sin socio',
                'responsable' => $v['responsable'] ?: 'Sin responsable',
                'fecha'       => $fecha,
                'dias'        => diasDesdeHoy($fecha),
            ];
        }
    }
}

// --- Rutas disponibles (para el formulario) ---
$rutas = $pdo->query('SELECT * FROM rutas ORDER BY nombre')->fetchAll();

// --- Si venimos a editar un vehículo, traer también sus 4 documentos ---
$editando = null;
if (!empty($_GET['editar'])) {
    $stmt = $pdo->prepare('
        SELECT v.id, v.placa, s.nombre AS socio, rp.nombre AS responsable
        FROM vehiculos v
        LEFT JOIN socios s ON s.id = v.socio_id
        LEFT JOIN responsables rp ON rp.id = v.responsable_id
        WHERE v.id = ?
    ');
    $stmt->execute([(int) $_GET['editar']]);
    $editando = $stmt->fetch() ?: null;

    if ($editando) {
        $id = (int) $editando['id'];

        $stmt = $pdo->prepare('SELECT * FROM revisiones_tecnicas WHERE vehiculo_id = ? ORDER BY id DESC LIMIT 1');
        $stmt->execute([$id]);
        $editando['rt'] = $stmt->fetch() ?: [];

        $stmt = $pdo->prepare('SELECT * FROM soats WHERE vehiculo_id = ? ORDER BY id DESC LIMIT 1');
        $stmt->execute([$id]);
        $editando['soat'] = $stmt->fetch() ?: [];

        $stmt = $pdo->prepare('SELECT * FROM tarjetas_circulacion WHERE vehiculo_id = ? ORDER BY id DESC LIMIT 1');
        $stmt->execute([$id]);
        $editando['tc'] = $stmt->fetch() ?: [];

        $stmt = $pdo->prepare('SELECT * FROM concesiones_rutas WHERE vehiculo_id = ? ORDER BY id DESC LIMIT 1');
        $stmt->execute([$id]);
        $editando['cr'] = $stmt->fetch() ?: [];
    }
}

function val(array $a, string $k): string
{
    return htmlspecialchars((string) ($a[$k] ?? ''));
}

$err = match ($_GET['error'] ?? '') {
    'placa_vacia'     => 'Ingresa una placa.',
    'placa_duplicada' => 'La placa ya existe.',
    'guardar_error'   => 'No se pudo guardar. Revisa la base de datos.',
    default           => null,
};

// --- Botón "Renovar": suma meses a la fecha de vencimiento de un documento ---
function formRenovar(string $tipo, int $id, int $mesesPorDefecto): string
{
    return '<form action="renovar.php" method="POST" class="renovar-form">'
         . '<input type="hidden" name="tipo" value="' . htmlspecialchars($tipo) . '">'
         . '<input type="hidden" name="id" value="' . $id . '">'
         . '<input type="number" name="meses" value="' . $mesesPorDefecto . '" min="1" title="Meses a sumar">'
         . '<button type="submit" class="btn btn-sm btn-outline-primary py-0">Renovar</button>'
         . '</form>';
}

// --- Un badge colapsable: al hacer clic se abre/cierra el detalle debajo ---
function docToggleAbre(string $nombre, ?string $fecha): string
{
    $estado = estadoDocumento($fecha);
    return '<details class="doc-toggle"><summary class="doc-summary ' . claseEstado($estado) . '">'
         . '<b>' . htmlspecialchars($nombre) . '</b>'
         . '<small>' . htmlspecialchars(textoDocumento($fecha)) . '</small>'
         . '</summary><div class="doc-content">';
}
function docToggleCierra(): string
{
    return '</div></details>';
}

// --- Placas que coinciden con el filtro de documentos ---
$placasAlertas = [];
if ($filtroAlerta !== '') {
    $modo = $filtroAlerta === 'vencidos' ? 'vencido' : 'porvencer';
    foreach ($todos as $v) {
        if ($socioId !== '' && (string) $v['socio_id'] !== (string) $socioId) {
            continue;
        }
        if ($responsableId !== '' && (string) $v['responsable_id'] !== (string) $responsableId) {
            continue;
        }
        foreach ($docs as $campo => $nombreDoc) {
            $fecha = $v[$campo] ?? null;
            if (estadoDocumento($fecha) === $modo) {
                $clave = $v['id'] . '|' . $nombreDoc;
                if (!isset($placasAlertas[$clave])) {
                    $placasAlertas[$clave] = [
                        'placa' => $v['placa'],
                        'socio' => $v['socio'] ?: 'Sin socio',
                        'responsable' => $v['responsable'] ?: 'Sin responsable',
                        'documento' => $nombreDoc,
                        'fecha' => $fecha,
                    ];
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Control Vehicular TICLLAS</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  :root { --azul: #123f91; --azul2: #1767c9; --rojo: #d71920; --morado: #40218e; }
  * { box-sizing: border-box; }
  body { margin: 0; background: #f4f7fb; color: #17335f; font-family: Arial, Helvetica, sans-serif; }

  .top { height: 98px; background: #fff; border-bottom: 5px solid var(--rojo); display: flex; align-items: center; padding: 0 28px; gap: 24px; }
  .logo { height: 88px; width: 110px; object-fit: contain; }
  .brand h1 { margin: 0; color: #123f91; font-size: 25px; font-weight: 800; }
  .brand p { margin: 3px 0; color: #486485; }

  .layout { display: flex; min-height: calc(100vh - 98px); }
  .side { width: 240px; background: linear-gradient(180deg, #123f91, #052f73); color: #fff; padding: 18px 12px; }
  .side a { display: block; color: #fff; text-decoration: none; padding: 13px 14px; border-radius: 8px; margin: 4px 0; font-weight: 700; }
  .side a:hover, .side a.active { background: #2168c7; }
  .main { flex: 1; padding: 22px; min-width: 0; }

  .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
  .stat { background: #fff; border: 1px solid #dbe5f2; border-radius: 10px; padding: 15px; }
  .stat span { display: block; color: #657b98; }
  .stat b { font-size: 28px; }
  .stat.red b { color: #d71920; }
  .stat.orange b { color: #e28a00; }
  .stat.green b { color: #159b68; }
  .stat-filter { display:block; width:100%; text-align:left; cursor:pointer; text-decoration:none; color:inherit; }
  .stat-filter:hover { box-shadow:0 3px 10px rgba(0,0,0,.08); }
  .stat small { display:block; margin-top:5px; color:#536b87; font-size:11px; }
  .alert-plates { margin:14px 0; padding:14px; border:1px solid #b8d1f7; border-radius:8px; background:#eef5ff; }
  .alert-plates-title { font-weight:800; color:#173f86; margin-bottom:8px; }
  .alert-plate-row { display:flex; flex-wrap:wrap; gap:8px; align-items:center; padding:8px 0; border-bottom:1px solid #d7e5fa; }
  .alert-plate-row:last-child { border-bottom:0; }
  .alert-plate { background:#173f86; color:#fff; padding:4px 8px; border-radius:5px; font-weight:800; }
  .alert-doc { color:#334e70; }
  .alert-date { color:#637994; font-size:12px; }
  .clear-alert { margin-left:8px; font-weight:400; }


  .notice { margin: 16px 0; background: #fff; border: 1px solid #dbe5f2; border-radius: 10px; padding: 14px; }
  .notice h3 { font-size: 16px; margin: 0 0 8px; }
  .alert-item { padding: 8px 10px; border-left: 4px solid #f0a000; background: #fff9ed; margin: 5px 0; }

  .search { max-width: 460px; }
  .selector-card { background: #fff; border: 1px solid #d9e3ef; border-radius: 10px; padding: 14px 16px; margin-top: 12px; }

  .group { background: #fff; border: 1px solid #d9e3ef; border-radius: 12px; margin-top: 16px; overflow: hidden; box-shadow: 0 2px 7px #00000008; }
  .group-head { padding: 16px; border-bottom: 1px solid #e3eaf2; background: #fbfdff; }
  .chips { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
  .chip { background: #e8f2ff; color: #1255a1; border-radius: 15px; padding: 5px 9px; font-size: 12px; font-weight: 700; }

  .vehicle { padding: 16px; border-bottom: 1px solid #e6ebf2; }
  .vehicle:last-child { border-bottom: 0; }
  .plate { display: inline-block; background: #173f86; color: #fff; border-radius: 5px; padding: 7px 11px; font-weight: 800; letter-spacing: 1px; }

  .docs { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-top: 12px; }

  /* Badges colapsables: se ven igual que antes cerrados, y abren su detalle debajo al hacer clic */
  .doc-toggle { border: none; }
  .doc-summary {
    display: block; cursor: pointer; list-style: none;
    border: 1px solid; border-radius: 8px; padding: 8px;
  }
  .doc-summary::-webkit-details-marker { display: none; }
  .doc-summary::marker { content: ''; }
  .doc-summary b, .doc-summary small { display: block; }
  .doc-summary small { margin-top: 3px; }
  .doc-summary::after { content: '▸ ver detalle'; display: block; font-size: 10px; opacity: .65; margin-top: 4px; }
  .doc-toggle[open] .doc-summary::after { content: '▾ ocultar detalle'; }
  .doc-content { margin-top: 8px; }
  .doc-content .empty-doc { font-size: 12px; color: #6b7d96; padding: 6px 2px; }

  .badge-vigente   { background: #eaf7ef; color: #087a4b; border-color: #8ed1ae; }
  .badge-porvencer { background: #fff4df; color: #8a5300; border-color: #f0b451; }
  .badge-vencido   { background: #ffebeb; color: #a31212; border-color: #ef8989; }
  .badge-sin       { background: #f3f5f8; color: #667; border-color: #ccd4df; }

  .rt-table, .soat-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .rt-table th, .rt-table td, .soat-table th, .soat-table td { border: 1px solid #ccd5e0; padding: 8px; }
  .rt-table th { background: #f0f2f5; text-align: center; font-size: 11px; }
  .soat-table th { background: var(--morado); color: #fff; width: 190px; text-align: left; }

  .status { font-weight: 800; padding: 4px 8px; border-radius: 5px; }
  .status.vigente   { color: #087a4b; background: #eaf7ef; }
  .status.porvencer { color: #8a5300; background: #fff4df; }
  .status.vencido   { color: #a31212; background: #ffebeb; }

  .renovar-form { display: inline-flex; gap: 4px; align-items: center; margin-top: 6px; }
  .renovar-form input[type=number] { width: 56px; }

  .form-section { background: #fff; border: 1px solid #d9e3ef; border-radius: 12px; margin-top: 18px; padding: 18px; }
  .section-title { font-weight: 800; color: #173f86; font-size: 17px; margin-bottom: 12px; }
  .footer-note { font-size: 12px; color: #6b7d96; margin-top: 14px; }

  @media (max-width: 1000px) {
    .side { width: 190px; }
    .stats, .docs { grid-template-columns: repeat(2, 1fr); }
  }
  @media (max-width: 700px) {
    .top { height: auto; padding: 10px 15px; }
    .logo { height: 65px; width: 80px; }
    .brand h1 { font-size: 18px; }
    .layout { display: block; }
    .side { width: 100%; display: flex; overflow: auto; }
    .side a { white-space: nowrap; }
    .main { padding: 12px; }
    .stats { grid-template-columns: 1fr; }
    .docs { grid-template-columns: 1fr; }
    .rt-table { display: block; overflow: auto; }
  }
</style>
</head>
<body>

<header class="top">
  <img class="logo" src="assets/logo.png" alt="Empresa de Transportes Ticllas">
  <div class="brand">
    <h1>SISTEMA DE CONTROL VEHICULAR</h1>
    <p>Gestión de Socios, Responsables y Vehículos</p>
  </div>
</header>

<div class="layout">
  <aside class="side">
    <a class="active" href="index.php">⌂ Inicio</a>
    <a href="#socios">👥 Socios</a>
    <a href="#vehiculos">🚍 Vehículos / Placas</a>
    <a href="#vencimientos">🔔 Vencimientos</a>
    <a href="rutas.php">🛣 Rutas y concesiones</a>
  </aside>

  <main class="main">

    <div class="stats">
      <a class="stat red stat-filter" href="index.php?alerta=vencidos<?= $socioId !== '' ? '&socio_id=' . urlencode($socioId) : '' ?><?= $responsableId !== '' ? '&responsable_id=' . urlencode($responsableId) : '' ?>">
        <span>Documentos vencidos</span><b><?= $vencidos ?></b><small>Ver placas</small>
      </a>
      <a class="stat orange stat-filter" href="index.php?alerta=porvencer<?= $socioId !== '' ? '&socio_id=' . urlencode($socioId) : '' ?><?= $responsableId !== '' ? '&responsable_id=' . urlencode($responsableId) : '' ?>">
        <span>Por vencer (30 días)</span><b><?= $por3 ?></b><small>Ver placas</small>
      </a>
      <div class="stat"><span>Alertas (3 días)</span><b><?= $conDocs ? count($alertas) : 0 ?></b></div>
      <div class="stat green"><span>Vehículos</span><b><?= count($todos) ?></b></div>
    </div>

    <?php if ($filtroAlerta !== ''): ?>
      <div class="alert-plates">
        <div class="alert-plates-title">
          <?= $filtroAlerta === 'vencidos' ? 'Placas con documentos vencidos' : 'Placas con documentos por vencer (30 días)' ?>
        </div>
        <?php if (!$placasAlertas): ?>
          <div class="text-muted">No hay placas que coincidan con este filtro.</div>
        <?php else: ?>
          <?php foreach ($placasAlertas as $a): ?>
            <div class="alert-plate-row">
              <span class="alert-plate"><?= htmlspecialchars($a['placa']) ?></span>
              <span class="alert-doc"><?= htmlspecialchars($a['documento']) ?></span>
              <span class="alert-date">Vence: <?= fechaCorta($a['fecha']) ?></span>
              <span class="alert-date">Responsable: <?= htmlspecialchars($a['responsable']) ?></span>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <div class="notice" id="vencimientos">
      <h3>🔔 Notificaciones — <?= count($alertas) ?> documento(s) dentro de 3 días</h3>
      <?php if (!$alertas): ?>
        <div class="text-muted">No hay vencimientos dentro de los próximos 3 días.</div>
      <?php else: ?>
        <?php foreach ($alertas as $a): ?>
          <div class="alert-item">
            <b><?= htmlspecialchars($a['documento']) ?></b> · <b><?= htmlspecialchars($a['placa']) ?></b> · <?= htmlspecialchars($a['socio']) ?> ·
            <?php if ($a['dias'] === 0): ?>vence hoy
            <?php elseif ($a['dias'] === 1): ?>vence mañana
            <?php else: ?>vence en <?= $a['dias'] ?> días
            <?php endif; ?>
            (<?= fechaCorta($a['fecha']) ?>)
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="d-flex justify-content-between align-items-center gap-2 flex-wrap" id="socios">
      <h2 class="h4 m-0">Socios, responsables y placas</h2>
      <form class="d-flex search" method="get">
        <input class="form-control" name="buscar" placeholder="Buscar socio, responsable o placa" value="<?= htmlspecialchars($buscar) ?>">
        <button class="btn btn-primary ms-2">Buscar</button>
      </form>
    </div>

    <div class="selector-card">
      <form method="get" class="row g-2 align-items-end">
        <div class="col-md-5">
          <label class="form-label">1. Elige un socio</label>
          <select name="socio_id" class="form-select" onchange="this.form.submit()">
            <option value="">— Selecciona —</option>
            <?php foreach ($socios as $s): ?>
              <option value="<?= $s['id'] ?>" <?= (string) $socioId === (string) $s['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($s['nombre']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-5">
          <label class="form-label">2. Elige un responsable</label>
          <select name="responsable_id" class="form-select" onchange="this.form.submit()" <?= $socioId === '' ? 'disabled' : '' ?>>
            <option value="">Todos los responsables de este socio</option>
            <?php foreach ($responsablesDelSocio as $r): ?>
              <option value="<?= $r['id'] ?>" <?= (string) $responsableId === (string) $r['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($r['nombre']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2">
          <?php if ($socioId !== ''): ?>
            <a href="index.php" class="btn btn-outline-secondary w-100">Limpiar</a>
          <?php endif; ?>
        </div>
      </form>
    </div>

    <?php if ($err): ?>
      <div class="alert alert-danger mt-3"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>

    <?php if (!$mostrarVehiculos): ?>
      <div class="group p-5 text-center text-muted">Elige un socio arriba para ver sus vehículos.</div>
    <?php else: ?>

    <?php if (!$vehiculos): ?>
      <div class="group p-5 text-center text-muted">No hay vehículos que coincidan con la búsqueda.</div>
    <?php endif; ?>

    <?php
    $grupos = [];
    foreach ($vehiculos as $v) {
        $grupos[$v['socio'] ?: 'SIN SOCIO'][] = $v;
    }
    ?>

    <?php foreach ($grupos as $socio => $items): ?>
      <section class="group" id="vehiculos">
        <div class="group-head">
          <div class="fw-bold fs-5">👤 Socio: <?= htmlspecialchars($socio) ?></div>

          <div class="chips">
            <strong>Responsables:</strong>
            <?php
            $responsablesDelGrupo = [];
            foreach ($items as $v) {
                if ($v['responsable'] && !in_array($v['responsable'], $responsablesDelGrupo, true)) {
                    $responsablesDelGrupo[] = $v['responsable'];
                }
            }
            ?>
            <?php foreach ($responsablesDelGrupo as $r): ?>
              <span class="chip"><?= htmlspecialchars($r) ?></span>
            <?php endforeach; ?>
            <?php if (!$responsablesDelGrupo): ?>
              <span class="chip">Sin responsable</span>
            <?php endif; ?>
          </div>

          <div class="chips">
            <strong>Placas:</strong>
            <?php foreach ($items as $v): ?>
              <span class="chip"><?= htmlspecialchars($v['placa']) ?></span>
            <?php endforeach; ?>
          </div>
        </div>

        <?php foreach ($items as $v): ?>
          <article class="vehicle">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
              <div>
                <span class="plate"><?= htmlspecialchars($v['placa']) ?></span>
                <span class="text-muted small">Responsable: <?= htmlspecialchars($v['responsable'] ?: 'Sin responsable') ?></span>
              </div>
              <div>
                <a class="btn btn-sm btn-outline-primary" href="index.php?editar=<?= $v['id'] ?>#formulario">Editar</a>
                <form class="d-inline" action="eliminar.php" method="post" onsubmit="return confirm('¿Eliminar este vehículo?')">
                  <input type="hidden" name="id" value="<?= $v['id'] ?>">
                  <button class="btn btn-sm btn-outline-danger">Eliminar</button>
                </form>
              </div>
            </div>

            <div class="docs">

              <?= docToggleAbre('Revisión técnica', $v['rt_vigente_hasta']) ?>
                <?php if (!empty($v['rt_certificado']) || !empty($v['rt_vigente_hasta']) || !empty($v['rt_resultado'])): ?>
                  <div class="table-responsive">
                    <table class="rt-table">
                      <tr><th>PLACA</th><th>N° CERTIFICADO</th><th>DESDE</th><th>HASTA</th><th>RESULTADO</th><th>ESTADO</th></tr>
                      <tr>
                        <td><?= htmlspecialchars($v['placa']) ?></td>
                        <td><?= htmlspecialchars($v['rt_certificado'] ?: '—') ?></td>
                        <td><?= fechaCorta($v['rt_vigente_desde']) ?></td>
                        <td><?= fechaCorta($v['rt_vigente_hasta']) ?></td>
                        <td><?= htmlspecialchars(strtoupper($v['rt_resultado'] ?: 'SIN REGISTRAR')) ?></td>
                        <td><span class="status <?= estadoDocumento($v['rt_vigente_hasta']) ?>"><?= estadoTexto($v['rt_vigente_hasta']) ?></span></td>
                      </tr>
                    </table>
                  </div>
                  <?= formRenovar('rt', (int) $v['rt_id'], 6) ?>
                <?php else: ?>
                  <div class="empty-doc">Sin datos registrados todavía. Edita el vehículo para completarlos.</div>
                <?php endif; ?>
              <?= docToggleCierra() ?>

              <?= docToggleAbre('SOAT', $v['soat_vigente_hasta']) ?>
                <?php if (!empty($v['soat_compania']) || !empty($v['soat_vigente_hasta']) || !empty($v['soat_certificado'])): ?>
                  <table class="soat-table">
                    <tr><th>Compañía</th><td><?= htmlspecialchars($v['soat_compania'] ?: '—') ?></td></tr>
                    <tr><th>Estado</th><td><span class="status <?= estadoDocumento($v['soat_vigente_hasta']) ?>"><?= estadoTexto($v['soat_vigente_hasta']) ?></span></td></tr>
                    <tr><th>Inicio</th><td><?= fechaCorta($v['soat_vigente_desde']) ?></td></tr>
                    <tr><th>Fin</th><td><?= fechaCorta($v['soat_vigente_hasta']) ?></td></tr>
                    <tr><th>Certificado</th><td><?= htmlspecialchars($v['soat_certificado'] ?: '—') ?></td></tr>
                    <tr><th>Uso</th><td><?= htmlspecialchars($v['soat_uso'] ?: '—') ?></td></tr>
                    <tr><th>Clase</th><td><?= htmlspecialchars($v['soat_clase'] ?: '—') ?></td></tr>
                    <tr><th>Tipo</th><td><?= htmlspecialchars($v['soat_tipo'] ?: '—') ?></td></tr>
                  </table>
                  <?= formRenovar('soat', (int) $v['soat_id'], 12) ?>
                <?php else: ?>
                  <div class="empty-doc">Sin datos registrados todavía. Edita el vehículo para completarlos.</div>
                <?php endif; ?>
              <?= docToggleCierra() ?>

              <?= docToggleAbre('Tarjeta de circulación', $v['tc_vigente_hasta']) ?>
                <?php if (!empty($v['tc_numero']) || !empty($v['tc_vigente_hasta'])): ?>
                  <table class="soat-table">
                    <tr><th>Número</th><td><?= htmlspecialchars($v['tc_numero'] ?: '—') ?></td></tr>
                    <tr><th>Vigente desde</th><td><?= fechaCorta($v['tc_vigente_desde']) ?></td></tr>
                    <tr><th>Vigente hasta</th><td><?= fechaCorta($v['tc_vigente_hasta']) ?></td></tr>
                    <tr><th>Estado</th><td><span class="status <?= estadoDocumento($v['tc_vigente_hasta']) ?>"><?= estadoTexto($v['tc_vigente_hasta']) ?></span></td></tr>
                  </table>
                  <?= formRenovar('tc', (int) $v['tc_id'], 12) ?>
                <?php else: ?>
                  <div class="empty-doc">Sin datos registrados todavía. Edita el vehículo para completarlos.</div>
                <?php endif; ?>
              <?= docToggleCierra() ?>

              <?= docToggleAbre('Concesión / Ruta', $v['cr_vigente_hasta']) ?>
                <?php if (!empty($v['ruta_nombre']) || !empty($v['cr_vigente_hasta'])): ?>
                  <table class="soat-table">
                    <tr><th>Ruta</th><td><?= htmlspecialchars($v['ruta_nombre'] ?: '—') ?></td></tr>
                    <tr><th>N° de concesión</th><td><?= htmlspecialchars($v['cr_numero_concesion'] ?: '—') ?></td></tr>
                    <tr><th>Vigente desde</th><td><?= fechaCorta($v['cr_vigente_desde']) ?></td></tr>
                    <tr><th>Vigente hasta</th><td><?= fechaCorta($v['cr_vigente_hasta']) ?></td></tr>
                    <tr><th>Estado</th><td><span class="status <?= estadoDocumento($v['cr_vigente_hasta']) ?>"><?= estadoTexto($v['cr_vigente_hasta']) ?></span></td></tr>
                  </table>
                <?php else: ?>
                  <div class="empty-doc">Sin datos registrados todavía. Edita el vehículo para completarlos.</div>
                <?php endif; ?>
              <?= docToggleCierra() ?>

            </div>
          </article>
        <?php endforeach; ?>
      </section>
    <?php endforeach; ?>
    <?php endif; // fin de $mostrarVehiculos ?>

    <div class="form-section" id="formulario">
      <div class="section-title"><?= $editando ? 'Editar vehículo' : 'Agregar vehículo' ?></div>

      <form action="guardar.php" method="post" class="row g-3">
        <?php if ($editando): ?>
          <input type="hidden" name="id" value="<?= $editando['id'] ?>">
        <?php endif; ?>

        <div class="col-md-4">
          <label class="form-label">Placa</label>
          <input required name="placa" class="form-control text-uppercase" value="<?= val($editando ?? [], 'placa') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Socio</label>
          <input name="socio" class="form-control" value="<?= val($editando ?? [], 'socio') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Responsable</label>
          <input name="responsable" class="form-control" value="<?= val($editando ?? [], 'responsable') ?>">
        </div>

        <div class="col-12"><hr><div class="section-title">Revisión técnica</div></div>
        <div class="col-md-3">
          <label class="form-label">N° certificado</label>
          <input name="rt_certificado" class="form-control" value="<?= val($editando['rt'] ?? [], 'numero_certificado') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Vigente desde</label>
          <input type="date" name="rt_vigente_desde" class="form-control" value="<?= val($editando['rt'] ?? [], 'vigente_desde') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Vigente hasta</label>
          <input type="date" name="rt_vigente_hasta" class="form-control" value="<?= val($editando['rt'] ?? [], 'vigente_hasta') ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Resultado</label>
          <select name="rt_resultado" class="form-select">
            <option value="">Sin registrar</option>
            <?php foreach (['Aprobado', 'Observado', 'Desaprobado'] as $o): ?>
              <option value="<?= $o ?>" <?= ($editando['rt']['resultado_inspeccion'] ?? '') === $o ? 'selected' : '' ?>><?= $o ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <?php $so = $editando['soat'] ?? []; ?>
        <div class="col-12"><hr><div class="section-title">SOAT — datos completos</div></div>
        <div class="col-md-4">
          <label class="form-label">Compañía</label>
          <input name="soat_compania" class="form-control" placeholder="Rimac Seguros" value="<?= val($so, 'compania') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Inicio</label>
          <input type="date" name="soat_vigente_desde" class="form-control" value="<?= val($so, 'vigente_desde') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Fin / vencimiento</label>
          <input type="date" name="soat_vigente_hasta" class="form-control" value="<?= val($so, 'vigente_hasta') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Certificado</label>
          <input name="soat_certificado" class="form-control" value="<?= val($so, 'certificado') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Uso</label>
          <input name="soat_uso" class="form-control" value="<?= val($so, 'uso') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Clase</label>
          <input name="soat_clase" class="form-control" value="<?= val($so, 'clase') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Tipo</label>
          <input name="soat_tipo" class="form-control" value="<?= val($so, 'tipo') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Fecha creación</label>
          <input type="datetime-local" name="soat_fecha_creacion" class="form-control"
                 value="<?= !empty($so['fecha_creacion']) ? date('Y-m-d\TH:i', strtotime($so['fecha_creacion'])) : '' ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Fecha anulación</label>
          <input type="datetime-local" name="soat_fecha_anulacion" class="form-control"
                 value="<?= !empty($so['fecha_anulacion']) ? date('Y-m-d\TH:i', strtotime($so['fecha_anulacion'])) : '' ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Control policial</label>
          <input type="date" name="soat_control_policial" class="form-control" value="<?= val($so, 'control_policial') ?>">
        </div>

        <?php $tc = $editando['tc'] ?? []; $cr = $editando['cr'] ?? []; ?>
        <div class="col-12"><hr><div class="section-title">Tarjeta de circulación</div></div>
        <div class="col-md-4">
          <label class="form-label">Número</label>
          <input name="tc_numero" class="form-control" value="<?= val($tc, 'numero') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Vigente desde</label>
          <input type="date" name="tc_vigente_desde" class="form-control" value="<?= val($tc, 'vigente_desde') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Vigente hasta</label>
          <input type="date" name="tc_vigente_hasta" class="form-control" value="<?= val($tc, 'vigente_hasta') ?>">
        </div>
        <div class="col-12">
          <label class="form-label">Observaciones</label>
          <input name="tc_observaciones" class="form-control" value="<?= val($tc, 'observaciones') ?>">
        </div>

        <div class="col-12"><hr><div class="section-title">Concesión / Ruta</div></div>
        <div class="col-md-4">
          <label class="form-label">Ruta</label>
          <select name="ruta_id" class="form-select">
            <option value="">Sin ruta</option>
            <?php foreach ($rutas as $r): ?>
              <option value="<?= $r['id'] ?>" <?= ((string) ($cr['ruta_id'] ?? '')) === (string) $r['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($r['nombre']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">N° concesión</label>
          <input name="cr_numero_concesion" class="form-control" value="<?= val($cr, 'numero_concesion') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Vigente hasta</label>
          <input type="date" name="cr_vigente_hasta" class="form-control" value="<?= val($cr, 'vigente_hasta') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Vigente desde</label>
          <input type="date" name="cr_vigente_desde" class="form-control" value="<?= val($cr, 'vigente_desde') ?>">
        </div>
        <div class="col-12">
          <label class="form-label">Observaciones</label>
          <input name="cr_observaciones" class="form-control" value="<?= val($cr, 'observaciones') ?>">
        </div>

        <div class="col-12">
          <button class="btn btn-primary"><?= $editando ? 'Actualizar vehículo' : 'Guardar vehículo' ?></button>
          <?php if ($editando): ?>
            <a class="btn btn-outline-secondary ms-2" href="index.php">Cancelar</a>
          <?php endif; ?>
        </div>
      </form>

      <div class="footer-note">Las alertas se calculan automáticamente con la fecha de vencimiento. El aviso aparece desde 3 días antes.</div>
    </div>

  </main>
</div>
</body>
</html>
