<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/config.php';

function require_login(): void {
    if (empty($_SESSION['usuario_id'])) {
        header('Location: login.php');
        exit;
    }
}

function current_role(): string {
    return strtoupper((string)($_SESSION['rol'] ?? ''));
}

function can_edit(): bool {
    return in_array(current_role(), ['ADMIN', 'EDITOR'], true);
}

function require_edit(): void {
    require_login();
    if (!can_edit()) {
        http_response_code(403);
        exit('No tienes permisos para realizar esta acción.');
    }
}

function require_admin(): void {
    require_login();
    if (current_role() !== 'ADMIN') {
        http_response_code(403);
        exit('Solo el administrador puede realizar esta acción.');
    }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

function verify_csrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(419);
        exit('Solicitud no válida. Recarga la página e inténtalo nuevamente.');
    }
}
