<?php
require_once __DIR__ . '/auth.php';
require_login();
require 'config.php';
require 'functions.php';

$rutas = $pdo->query('
    SELECT r.*, COUNT(v.id) AS total_vehiculos
    FROM rutas r
    LEFT JOIN concesiones_rutas cr ON cr.ruta_id = r.id
    LEFT JOIN vehiculos v ON v.id = cr.vehiculo_id
    GROUP BY r.id
    ORDER BY r.nombre
')->fetchAll();

$editando = null;
if (!empty($_GET['editar'])) {
    $stmt = $pdo->prepare('SELECT * FROM rutas WHERE id = :id');
    $stmt->execute(['id' => $_GET['editar']]);
    $editando = $stmt->fetch() ?: null;
}

$mensajeError = match ($_GET['error'] ?? '') {
    'nombre_vacio' => 'Ingresa el nombre de la ruta.',
    default => null,
};
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Rutas y concesiones</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body{ background:#F1F2EF; }
  header.band{ background:#1E2328; color:#F1F2EF; padding:2rem 0 1.75rem; }
  header.band .sub{ color:#B7BDC2; }
  header.band a{ color:#9BD4E4; }
  .badge-doc{
    display:inline-block; border-radius:6px; border:1px solid;
    padding:.3rem .55rem; font-size:.78rem; margin:2px;
  }
  .badge-vencido{ background:#FCEBEB; color:#501313; border-color:#E24B4A; }
  .badge-porvencer{ background:#FAEEDA; color:#633806; border-color:#EF9F27; }
  .badge-vigente{ background:#EAF3DE; color:#27500A; border-color:#97C459; }
  .badge-sin{ background:#F1EFE8; color:#444441; border-color:#B4B2A9; }
  .doc-name{ display:block; font-weight:600; }
  .renovar-form{ display:inline-flex; gap:4px; align-items:center; margin-left:6px; }
  .renovar-form input[type=number]{ width:56px; }
</style>
</head>
<body>

<header class="band">
  <div class="container">
    <h1 class="h3 fw-bold mb-1">Rutas y concesiones</h1>
    <p class="sub mb-2">Cada ruta se crea una vez y se asigna a varios vehículos</p>
    <a href="index.php">&larr; Volver a vehículos</a>
  </div>
</header>

<div class="container my-4">

  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <h2 class="h5 fw-semibold mb-3"><?= $editando ? 'Editar ruta' : 'Agregar ruta' ?></h2>

      <?php if ($mensajeError): ?>
        <div class="alert alert-danger py-2"><?= htmlspecialchars($mensajeError) ?></div>
      <?php endif; ?>

      <?php if (can_edit()): ?><form action="guardar_ruta.php" method="POST" class="row g-3">
      <?= csrf_field() ?>
        <?php if ($editando): ?>
          <input type="hidden" name="id" value="<?= htmlspecialchars($editando['id']) ?>">
        <?php endif; ?>

        <div class="col-md-4">
          <label class="form-label">Nombre de la ruta</label>
          <input type="text" name="nombre" class="form-control" required
                 placeholder="Ej: Huancayo - Lima"
                 value="<?= htmlspecialchars($editando['nombre'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Fecha de inauguración</label>
          <input type="date" name="fecha_inauguracion" class="form-control"
                 value="<?= htmlspecialchars($editando['fecha_inauguracion'] ?? '') ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Fecha de vencimiento</label>
          <input type="date" name="fecha_vencimiento" class="form-control"
                 value="<?= htmlspecialchars($editando['fecha_vencimiento'] ?? '') ?>">
        </div>

        <div class="col-12 d-flex gap-2 mt-2">
          <button type="submit" class="btn btn-primary"><?= $editando ? 'Actualizar ruta' : 'Guardar ruta' ?></button>
          <?php if ($editando): ?>
            <a href="rutas.php" class="btn btn-outline-secondary">Cancelar edición</a>
          <?php endif; ?>
        </div>
      </form><?php endif; ?>
    </div>
  </div>

  <?php if (empty($rutas)): ?>
    <div class="text-center text-muted py-5">Todavía no hay rutas registradas. Agrega la primera arriba.</div>
  <?php else: ?>
    <div class="d-flex flex-column gap-2">
      <?php foreach ($rutas as $r): ?>
        <?php $estado = estadoDocumento($r['fecha_vencimiento']); ?>
        <div class="card">
          <div class="card-body d-flex flex-wrap align-items-center gap-3">
            <div class="flex-grow-1">
              <div class="fw-semibold"><?= htmlspecialchars($r['nombre']) ?></div>
              <div class="text-muted small"><?= (int) $r['total_vehiculos'] ?> vehículo(s) asignado(s)</div>
            </div>

            <span class="badge-doc <?= claseEstado($estado) ?>">
              <span class="doc-name">Vencimiento de la concesión</span>
              <?= textoDocumento($r['fecha_vencimiento']) ?>

            </span>

            <div class="d-flex flex-column gap-1">
              <a href="rutas.php?editar=<?= $r['id'] ?>" class="btn btn-sm btn-link">Editar</a>
              <form action="eliminar_ruta.php" method="POST" onsubmit="return confirm('¿Eliminar la ruta <?= htmlspecialchars($r['nombre']) ?>? Los vehículos asignados quedarán sin ruta.');">
                <input type="hidden" name="id" value="<?= $r['id'] ?>">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-sm btn-link text-danger">Eliminar</button>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

</div>
</body>
</html>
