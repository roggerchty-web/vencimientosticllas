<?php
session_start();
require_once __DIR__ . '/config.php';

if (!empty($_SESSION['usuario_id'])) { header('Location: index.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($usuario === '' || $password === '') {
        $error = 'Ingrese el usuario y la contraseña.';
    } else {
        $stmt = $pdo->prepare('SELECT u.id,u.rol_id,u.nombre,u.usuario,u.password_hash,u.estado,r.nombre AS rol FROM usuarios u INNER JOIN roles r ON r.id=u.rol_id WHERE u.usuario=:usuario LIMIT 1');
        $stmt->execute([':usuario'=>$usuario]);
        $user = $stmt->fetch();
        if ($user && $user['estado'] === 'ACTIVO' && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['usuario_id'] = (int)$user['id'];
            $_SESSION['usuario_nombre'] = $user['nombre'];
            $_SESSION['usuario'] = $user['usuario'];
            $_SESSION['rol_id'] = (int)$user['rol_id'];
            $_SESSION['rol'] = $user['rol'];
            $pdo->prepare('UPDATE usuarios SET ultimo_acceso=NOW() WHERE id=:id')->execute([':id'=>$user['id']]);
            header('Location: index.php'); exit;
        }
        $error = 'Usuario o contraseña incorrectos.';
    }
}
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Acceso - TICLLAS</title>
<style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:Arial,sans-serif;background:#f4f7fb}.login{width:100%;max-width:410px;background:#fff;padding:30px;border-radius:12px;box-shadow:0 8px 25px rgba(0,0,0,.12);border-top:5px solid #d71920}.logo{display:block;width:100px;height:80px;object-fit:contain;margin:0 auto 8px}h1{text-align:center;color:#123f91;font-size:23px;margin:0}.sub{text-align:center;color:#66788f;margin:7px 0 22px}label{display:block;font-weight:700;margin:12px 0 6px}input{width:100%;padding:12px;border:1px solid #ccd7e5;border-radius:7px;font-size:15px}button{width:100%;padding:12px;margin-top:20px;border:0;border-radius:7px;background:#1767c9;color:#fff;font-size:16px;font-weight:700;cursor:pointer}.error{background:#f8d7da;color:#842029;padding:10px;border-radius:7px;margin-bottom:12px;text-align:center}</style></head><body><div class="login"><img class="logo" src="assets/logo.png" alt="TICLLAS"><h1>Empresa de Transportes Ticllas SAC</h1><div class="sub">Sistema de control vehicular</div><?php if($error): ?><div class="error"><?=htmlspecialchars($error)?></div><?php endif; ?><form method="post"><label>Usuario</label><input name="usuario" autocomplete="username" required><label>Contraseña</label><input type="password" name="password" autocomplete="current-password" required><button>Iniciar sesión</button></form></div></body></html>
