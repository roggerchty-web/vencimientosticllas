<?php
// Cuántos días faltan (positivo) o ya pasaron (negativo) para una fecha
function diasDesdeHoy(?string $fecha): int
{
    if (!$fecha) {
        return 999999; // "sin fecha" nunca debe verse como urgente
    }
    $hoy = new DateTime('today');
    $f = new DateTime($fecha);
    return (int) $hoy->diff($f)->format('%r%a');
}

// Estado de un documento según su fecha: sin, vencido, porvencer, vigente
function estadoDocumento(?string $fecha): string
{
    if (!$fecha) {
        return 'sin';
    }
    $dias = diasDesdeHoy($fecha);
    if ($dias < 0) return 'vencido';
    if ($dias <= 30) return 'porvencer';
    return 'vigente';
}

// Texto corto para mostrar junto a la fecha (ej: "13/11/2026 · vence en 67 d")
function textoDocumento(?string $fecha): string
{
    if (!$fecha) {
        return 'Sin registrar';
    }
    $dias = diasDesdeHoy($fecha);
    $fechaFmt = (new DateTime($fecha))->format('d/m/Y');

    if ($dias < 0) return "$fechaFmt · venció hace " . abs($dias) . ' d';
    if ($dias === 0) return "$fechaFmt · vence hoy";
    return "$fechaFmt · vence en $dias d";
}

// Clase CSS para pintar el badge según el estado
function claseEstado(string $estado): string
{
    return match ($estado) {
        'vencido'   => 'badge-vencido',
        'porvencer' => 'badge-porvencer',
        'vigente'   => 'badge-vigente',
        default     => 'badge-sin',
    };
}

// Fecha en formato corto (dd/mm/aaaa), o un guion si no hay fecha
function fechaCorta(?string $fecha): string
{
    return $fecha ? (new DateTime($fecha))->format('d/m/Y') : '—';
}

// Palabra en mayúsculas para la columna "Estado" de las tablas de detalle
function estadoTexto(?string $fecha): string
{
    return match (estadoDocumento($fecha)) {
        'vencido'   => 'VENCIDO',
        'porvencer' => 'POR VENCER',
        'vigente'   => 'VIGENTE',
        default     => 'SIN REGISTRAR',
    };
}

// ¿Este documento vence dentro de los próximos 3 días? (para las notificaciones)
function alerta3(?string $fecha): bool
{
    if (!$fecha) {
        return false;
    }
    $dias = diasDesdeHoy($fecha);
    return $dias >= 0 && $dias <= 3;
}

// Suma una cantidad de meses a una fecha (esto es lo que usa el botón "Renovar")
function sumarMeses(string $fecha, int $meses): string
{
    $f = new DateTime($fecha);
    $f->modify("+$meses months");
    return $f->format('Y-m-d');
}
