-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: sql101.infinityfree.com
-- Tiempo de generación: 14-10-2026 a las 12:43:13
-- Versión del servidor: 11.4.13-MariaDB
-- Versión de PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_42835945_vencimientos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `concesiones_rutas`
--

CREATE TABLE `concesiones_rutas` (
  `id` int(10) UNSIGNED NOT NULL,
  `vehiculo_id` int(10) UNSIGNED NOT NULL,
  `ruta_id` int(10) UNSIGNED DEFAULT NULL,
  `numero_concesion` varchar(100) DEFAULT NULL,
  `vigente_desde` date DEFAULT NULL,
  `vigente_hasta` date DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsables`
--

CREATE TABLE `responsables` (
  `id` int(10) UNSIGNED NOT NULL,
  `socio_id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `responsables`
--

INSERT INTO `responsables` (`id`, `socio_id`, `nombre`, `creado_en`) VALUES
(1, 1, 'Dina Oroya Ticllas', '2026-09-07 17:46:31'),
(7, 7, 'Edwin Oroya Vila', '2026-09-07 20:30:47'),
(12, 7, 'Ana Oroya Vila', '2026-09-07 20:39:29'),
(15, 15, 'Rosalbina Oroya Ticllas', '2026-09-07 20:43:04'),
(19, 15, 'Jessica Rodrigo', '2026-09-07 20:46:37'),
(21, 21, 'Luis Oroya - Herlinda Molina', '2026-09-07 20:48:55'),
(26, 26, 'Yolanda Unsihuay', '2026-09-07 20:53:58'),
(33, 26, 'Milagros Oroya', '2026-09-07 21:02:14'),
(34, 35, 'Sebastiana Oroya Ticllas', '2026-09-07 21:03:33'),
(35, 35, 'Hector Chamorro', '2026-09-07 21:04:58'),
(37, 35, 'Edith Chamorro', '2026-09-07 21:06:39');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revisiones_tecnicas`
--

CREATE TABLE `revisiones_tecnicas` (
  `id` int(10) UNSIGNED NOT NULL,
  `vehiculo_id` int(10) UNSIGNED NOT NULL,
  `numero_certificado` varchar(80) DEFAULT NULL,
  `vigente_desde` date DEFAULT NULL,
  `vigente_hasta` date DEFAULT NULL,
  `resultado_inspeccion` varchar(40) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `revisiones_tecnicas`
--

INSERT INTO `revisiones_tecnicas` (`id`, `vehiculo_id`, `numero_certificado`, `vigente_desde`, `vigente_hasta`, `resultado_inspeccion`, `estado`, `creado_en`, `actualizado_en`) VALUES
(1, 1, 'C-2026-226-349-002301', '2026-09-19', '2027-03-19', 'Aprobado', NULL, '2026-09-07 17:46:31', '2026-09-21 15:10:39'),
(2, 2, 'C-2026-190-283-013072', '2026-05-13', '2026-11-13', 'Aprobado', NULL, '2026-09-07 17:50:00', '2026-09-07 17:50:00'),
(3, 3, 'C-2026-316-472-003474', '2026-07-02', '2027-01-02', 'Aprobado', NULL, '2026-09-07 20:12:57', '2026-09-07 20:12:57'),
(4, 4, 'C-2026-190-283-013178', '2026-05-14', '2026-11-14', 'Aprobado', NULL, '2026-09-07 20:21:19', '2026-09-07 20:21:19'),
(5, 5, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:24:48', '2026-09-07 20:24:48'),
(6, 6, 'C-2026-190-283-012995', '2026-05-12', '2027-05-12', 'Aprobado', NULL, '2026-09-07 20:27:34', '2026-09-07 20:27:34'),
(7, 7, 'C-2026-190-283-019060', '2026-07-14', '2027-01-14', 'Aprobado', NULL, '2026-09-07 20:30:47', '2026-09-07 20:30:47'),
(8, 8, 'C-2026-190-283-007307', '2026-09-08', '2027-03-08', 'Aprobado', NULL, '2026-09-07 20:33:56', '2026-09-15 15:38:09'),
(9, 9, 'C-2026-373-568-005652', '2026-05-18', '2026-11-18', 'Aprobado', NULL, '2026-09-07 20:35:28', '2026-09-07 20:35:28'),
(10, 10, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:36:41', '2026-09-07 20:36:41'),
(11, 11, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:38:12', '2026-09-07 20:38:12'),
(12, 12, 'C-2026-222-341-002117', '2026-08-24', '2027-02-24', 'Aprobado', NULL, '2026-09-07 20:39:29', '2026-09-07 20:39:29'),
(13, 13, 'C-2026-196-294-006231', '2026-06-06', '2026-12-06', 'Aprobado', NULL, '2026-09-07 20:40:31', '2026-09-07 20:40:31'),
(14, 14, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:41:27', '2026-09-07 20:41:27'),
(15, 15, 'C-2026-330-490-004075', '2026-08-26', '2027-02-26', 'Aprobado', NULL, '2026-09-07 20:43:04', '2026-09-07 20:43:04'),
(16, 16, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:43:54', '2026-09-07 20:43:54'),
(17, 17, 'C-2026-190-283-014370', '2026-05-27', '2026-11-27', 'Aprobado', NULL, '2026-09-07 20:44:56', '2026-09-07 20:44:56'),
(18, 18, 'C-2026-190-283-019005', '2026-07-13', '2027-01-13', 'Aprobado', NULL, '2026-09-07 20:46:37', '2026-09-07 20:46:37'),
(19, 19, 'C-2026-255-395-005266', '2026-07-08', '2027-01-08', 'Aprobado', NULL, '2026-09-07 20:47:24', '2026-09-07 20:47:24'),
(20, 20, 'C-2026-047-071-003099', '2026-04-22', '2026-10-22', 'Aprobado', NULL, '2026-09-07 20:48:55', '2026-09-07 20:48:55'),
(21, 21, 'C-2026-190-283-019884', '2026-07-21', '2027-01-21', 'Aprobado', NULL, '2026-09-07 20:49:40', '2026-09-07 20:49:40'),
(22, 22, 'C-2026-316-472-002581', '2026-05-14', '2026-11-14', 'Aprobado', NULL, '2026-09-07 20:50:29', '2026-09-07 20:50:29'),
(23, 23, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:51:25', '2026-09-07 20:51:25'),
(24, 24, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:52:13', '2026-09-07 20:52:13'),
(25, 25, 'C-2026-190-283-016851', '2026-06-23', '2026-12-23', 'Aprobado', NULL, '2026-09-07 20:53:02', '2026-09-07 20:53:58'),
(26, 26, 'C-2026-190-283-013283', '2026-05-15', '2026-11-15', 'Aprobado', NULL, '2026-09-07 20:55:00', '2026-09-07 20:55:00'),
(27, 27, 'C-2026-190-283-018391', '2026-07-08', '2027-01-08', 'Aprobado', NULL, '2026-09-07 20:56:19', '2026-09-07 20:56:19'),
(28, 28, 'C-2026-373-568-006471', '2026-06-11', '2026-12-11', 'Aprobado', NULL, '2026-09-07 20:57:12', '2026-09-07 20:57:12'),
(29, 29, 'C-2026-190-283-008203', '2026-09-17', '2027-03-17', 'Aprobado', NULL, '2026-09-07 20:58:11', '2026-09-19 15:58:52'),
(30, 30, 'C-2026-190-283-009413', '2026-03-30', '2026-09-30', 'Aprobado', NULL, '2026-09-07 20:59:25', '2026-09-07 20:59:25'),
(31, 31, 'C-2025-190-283-026128', '2025-11-15', '2026-05-15', 'Aprobado', NULL, '2026-09-07 21:00:21', '2026-09-07 21:00:21'),
(32, 32, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:02:14', '2026-09-07 21:02:14'),
(33, 33, 'C-2026-190-283-020147', '2026-07-23', '2027-01-23', 'Aprobado', NULL, '2026-09-07 21:03:33', '2026-09-07 21:03:33'),
(34, 34, 'C-2025-190-283-028654', '2025-12-16', '2026-06-16', 'Aprobado', NULL, '2026-09-07 21:04:58', '2026-09-07 21:04:58'),
(35, 35, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:05:48', '2026-09-07 21:05:48'),
(36, 36, 'C-2026-190-283-011930', '2026-04-29', '2026-10-29', 'Aprobado', NULL, '2026-09-07 21:06:39', '2026-09-07 21:06:39'),
(37, 37, 'C-2026-060-115-005853', '2026-08-11', '2027-02-11', 'Aprobado', NULL, '2026-09-07 21:07:37', '2026-09-07 21:07:37'),
(38, 38, 'C-2026-383-581-000850', '2026-04-14', '2026-10-14', 'Aprobado', NULL, '2026-09-07 21:08:24', '2026-09-07 21:08:24'),
(39, 39, 'C-2026-190-283-015721', '2026-06-12', '2026-12-12', 'Aprobado', NULL, '2026-09-07 21:09:12', '2026-09-07 21:09:12'),
(40, 40, 'C-2026-047-071-002056', '2026-09-10', '2027-03-10', 'Aprobado', NULL, '2026-09-07 21:09:57', '2026-09-15 15:39:44'),
(41, 41, 'C-2026-190-283-018835', '2026-07-11', '2027-01-11', 'Aprobado', NULL, '2026-09-07 21:10:45', '2026-09-07 21:10:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES
(1, 'ADMIN', 'Acceso total y gestión de usuarios'),
(2, 'EDITOR', 'Puede registrar, editar, renovar y eliminar información'),
(3, 'CONSULTA', 'Solo puede consultar información');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutas`
--

CREATE TABLE `rutas` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `fecha_inauguracion` date DEFAULT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rutas`
--

INSERT INTO `rutas` (`id`, `nombre`, `fecha_inauguracion`, `fecha_vencimiento`, `creado_en`, `actualizado_en`) VALUES
(1, 'Huancayo - Huancavelica (viceversa)', '2015-12-01', '2025-12-01', '2026-09-15 15:14:27', '2026-09-15 15:14:27'),
(2, 'Huancayo - Ayacucho (viceversa)', '2015-07-03', '2025-07-03', '2026-09-15 15:16:03', '2026-09-15 15:16:03'),
(3, 'Lima - La Merced (viceversa)', '2014-01-07', '2024-01-07', '2026-09-16 15:18:35', '2026-09-16 15:18:35'),
(4, 'Lima - Acobamba (viceversa)', '2022-12-14', '2032-12-14', '2026-09-16 15:20:00', '2026-09-16 15:21:08'),
(5, 'Ica - Ayacucho (viceversa)', '2026-03-05', '2036-03-05', '2026-09-16 15:20:55', '2026-09-16 15:23:01'),
(6, 'Ica - Huanta (viceversa)', '2025-02-03', '2035-02-03', '2026-09-16 15:21:58', '2026-09-16 15:21:58'),
(7, 'Satipo - Andahuaylas (viceversa)', '2025-06-10', '2035-06-10', '2026-09-16 15:22:49', '2026-09-16 15:22:49');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seguros`
--

CREATE TABLE `seguros` (
  `id` int(10) UNSIGNED NOT NULL,
  `vehiculo_id` int(10) UNSIGNED NOT NULL,
  `aseguradora` varchar(150) DEFAULT NULL,
  `poliza` varchar(100) DEFAULT NULL,
  `certificado` varchar(100) DEFAULT NULL,
  `periodo` varchar(20) DEFAULT NULL,
  `endosado` varchar(30) DEFAULT NULL,
  `suma_asegurada` decimal(14,2) DEFAULT NULL,
  `vigente_desde` date DEFAULT NULL,
  `vigente_hasta` date DEFAULT NULL,
  `prima_total_usd` decimal(12,2) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seguro_pagos`
--

CREATE TABLE `seguro_pagos` (
  `id` int(10) UNSIGNED NOT NULL,
  `seguro_id` int(10) UNSIGNED NOT NULL,
  `numero_cuota` int(10) UNSIGNED DEFAULT NULL,
  `tipo` varchar(30) DEFAULT NULL,
  `documento_generado` varchar(100) DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `monto_usd` decimal(12,2) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `soats`
--

CREATE TABLE `soats` (
  `id` int(10) UNSIGNED NOT NULL,
  `vehiculo_id` int(10) UNSIGNED NOT NULL,
  `compania` varchar(120) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `vigente_desde` date DEFAULT NULL,
  `vigente_hasta` date DEFAULT NULL,
  `certificado` varchar(100) DEFAULT NULL,
  `poliza` varchar(100) DEFAULT NULL,
  `uso` varchar(80) DEFAULT NULL,
  `clase` varchar(80) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `prima_anual` decimal(12,2) DEFAULT NULL,
  `prima_por_asiento` decimal(12,2) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_anulacion` datetime DEFAULT NULL,
  `control_policial` date DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `soats`
--

INSERT INTO `soats` (`id`, `vehiculo_id`, `compania`, `estado`, `vigente_desde`, `vigente_hasta`, `certificado`, `poliza`, `uso`, `clase`, `tipo`, `prima_anual`, `prima_por_asiento`, `fecha_creacion`, `fecha_anulacion`, `control_policial`, `creado_en`, `actualizado_en`) VALUES
(1, 1, 'Rimac Seguros', NULL, '2026-07-22', '2027-07-22', '000011982539000000000016', NULL, 'INTERPROVINCIAL', 'OMNIBUS', 'DIGITAL', NULL, NULL, '2026-07-20 23:00:00', NULL, '2026-07-29', '2026-09-07 17:46:31', '2026-09-07 17:46:31'),
(2, 2, 'Rimac Seguros', NULL, '2026-07-22', '2027-07-22', '000011982539000000000012', NULL, 'INTERPROVINCIAL', 'OMNIBUS', 'DIGITAL', NULL, NULL, '2026-07-20 23:00:00', NULL, '2026-09-22', '2026-09-07 17:50:00', '2026-09-07 17:50:00'),
(3, 3, 'Rimac Seguros', NULL, '2026-07-22', '2027-07-22', '000011982539000000000019', NULL, 'INTERPROVINCIAL', 'OMNIBUS', 'DIGITAL', NULL, NULL, '2026-07-20 23:00:00', NULL, '2026-09-22', '2026-09-07 20:12:57', '2026-09-07 20:12:57'),
(4, 4, NULL, NULL, '2026-07-20', '2027-07-22', '000011982539000000000019', NULL, 'INTERPROVINCIAL', 'OMNIBUS', 'DIGITAL', NULL, NULL, '2026-07-20 23:00:00', NULL, '2026-09-22', '2026-09-07 20:21:19', '2026-09-07 20:21:19'),
(5, 5, 'Rimac Seguros', NULL, '2025-11-30', '2026-11-30', '000011831972000000000007', NULL, 'TURISMO', 'MINIBUS', 'DIGITAL', NULL, NULL, '2025-11-30 12:09:00', NULL, '2026-11-30', '2026-09-07 20:24:48', '2026-09-07 20:24:48'),
(6, 6, 'Rimac Seguros', NULL, '2025-10-14', '2027-10-14', '000011808547000000000001', NULL, 'TURISMO', 'MICROBUS', 'DIGITAL', NULL, NULL, '2025-10-15 09:47:00', NULL, '2026-10-14', '2026-09-07 20:27:34', '2026-09-07 20:27:34'),
(7, 7, 'Rimac Seguros', NULL, '2026-07-22', '2027-07-22', '000011982539000000000010', NULL, 'INTERPROVINCIAL', 'OMNIBUS', 'DIGITAL', NULL, NULL, '2026-07-20 23:00:00', NULL, '2026-09-22', '2026-09-07 20:30:47', '2026-09-07 20:30:47'),
(8, 8, 'Rimac Seguros', NULL, '2026-07-22', '2027-07-22', '000011982539000000000004', NULL, 'INTERPROVINCIAL', 'OMNIBUS', 'DIGITAL', NULL, NULL, '2026-07-20 23:00:00', NULL, '2026-09-22', '2026-09-07 20:33:56', '2026-09-07 20:33:56'),
(9, 21, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:04:04', '2026-09-11 15:04:04'),
(10, 23, NULL, NULL, NULL, '2027-06-13', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:04:46', '2026-09-11 15:04:46'),
(11, 24, NULL, NULL, NULL, '2026-11-30', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:05:23', '2026-09-11 15:05:23'),
(12, 20, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:06:03', '2026-09-11 15:06:03'),
(13, 22, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:07:37', '2026-09-11 15:07:37'),
(14, 14, NULL, NULL, NULL, '2026-11-30', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:08:32', '2026-09-11 15:08:32'),
(15, 13, NULL, NULL, NULL, '2027-05-16', NULL, NULL, 'TRANSP DE PERSONAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:09:22', '2026-09-11 15:09:22'),
(16, 12, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:10:08', '2026-09-11 15:10:08'),
(17, 9, NULL, NULL, NULL, '2027-05-16', NULL, NULL, 'TRANSP DE PERSONAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:10:42', '2026-09-11 15:10:42'),
(18, 10, NULL, NULL, NULL, '2027-06-13', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:11:23', '2026-09-11 15:11:23'),
(19, 11, NULL, NULL, NULL, '2026-11-30', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:12:01', '2026-09-11 15:12:01'),
(20, 19, NULL, NULL, NULL, '2027-04-30', NULL, NULL, 'TRANSP DE PERSONAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:13:26', '2026-09-11 15:13:26'),
(21, 18, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:15:04', '2026-09-11 15:15:04'),
(22, 15, NULL, NULL, NULL, '2027-02-27', NULL, NULL, 'TURISMO', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:15:36', '2026-09-11 15:15:36'),
(23, 16, NULL, NULL, NULL, '2027-06-13', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:16:10', '2026-09-11 15:16:10'),
(24, 17, NULL, NULL, NULL, '2026-11-25', NULL, NULL, 'TURISMO', 'MICROBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:17:01', '2026-09-11 15:17:01'),
(25, 40, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:17:43', '2026-09-11 15:17:43'),
(26, 41, NULL, NULL, NULL, '2027-06-13', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:18:15', '2026-09-11 15:18:15'),
(27, 39, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:19:02', '2026-09-11 15:19:02'),
(28, 36, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:19:30', '2026-09-11 15:19:30'),
(29, 38, NULL, NULL, NULL, '2026-11-14', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:20:04', '2026-09-11 15:20:04'),
(30, 37, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:20:39', '2026-09-11 15:20:39'),
(31, 35, NULL, NULL, NULL, '2026-11-30', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:21:08', '2026-09-11 15:21:08'),
(32, 34, NULL, NULL, NULL, '2026-12-11', NULL, NULL, 'TURISMO', 'MULTIPROPOSITO', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:21:45', '2026-09-11 15:21:45'),
(33, 33, NULL, NULL, NULL, '2027-07-06', NULL, NULL, 'TURISMO', 'MICROBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:22:15', '2026-09-11 15:22:15'),
(34, 32, NULL, NULL, NULL, '2026-11-30', NULL, NULL, 'TURISMO', 'MINIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:23:01', '2026-09-11 15:23:01'),
(35, 31, NULL, NULL, NULL, '2026-11-13', NULL, NULL, 'TURISMO', 'MICROBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:23:34', '2026-09-11 15:23:34'),
(36, 30, NULL, NULL, NULL, '2027-07-06', NULL, NULL, 'TURISMO', 'MICROBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:24:21', '2026-09-11 15:24:21'),
(37, 25, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:24:52', '2026-09-11 15:24:52'),
(38, 28, NULL, NULL, NULL, '2027-06-04', NULL, NULL, 'TRANSP DE PERSONAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:25:30', '2026-09-11 15:25:30'),
(39, 26, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:26:16', '2026-09-11 15:26:16'),
(40, 29, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:26:56', '2026-09-11 15:26:56'),
(41, 27, NULL, NULL, NULL, '2027-07-22', NULL, NULL, 'INTERPROVINCIAL', 'OMNIBUS', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 15:27:38', '2026-09-11 15:27:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `soat_pagos`
--

CREATE TABLE `soat_pagos` (
  `id` int(10) UNSIGNED NOT NULL,
  `soat_id` int(10) UNSIGNED NOT NULL,
  `numero_cuota` int(10) UNSIGNED DEFAULT NULL,
  `tipo` varchar(30) DEFAULT NULL,
  `documento_generado` varchar(100) DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `monto_usd` decimal(12,2) DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `socios`
--

CREATE TABLE `socios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `numero_socio` varchar(50) DEFAULT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'ACTIVO',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `socios`
--

INSERT INTO `socios` (`id`, `nombre`, `numero_socio`, `estado`, `creado_en`) VALUES
(1, 'Dina Oroya', NULL, 'ACTIVO', '2026-09-07 17:46:31'),
(7, 'Marcial Oroya', NULL, 'ACTIVO', '2026-09-07 20:30:47'),
(15, 'Rosalbina Oroya', NULL, 'ACTIVO', '2026-09-07 20:43:04'),
(21, 'Luis Oroya', NULL, 'ACTIVO', '2026-09-07 20:48:55'),
(26, 'Yolanda Unsihuay', NULL, 'ACTIVO', '2026-09-07 20:53:02'),
(35, 'Sebastiana Oroya', NULL, 'ACTIVO', '2026-09-07 21:03:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarjetas_circulacion`
--

CREATE TABLE `tarjetas_circulacion` (
  `id` int(10) UNSIGNED NOT NULL,
  `vehiculo_id` int(10) UNSIGNED NOT NULL,
  `numero` varchar(100) DEFAULT NULL,
  `vigente_desde` date DEFAULT NULL,
  `vigente_hasta` date DEFAULT NULL,
  `razon_social` varchar(255) DEFAULT NULL,
  `ruc` varchar(30) DEFAULT NULL,
  `partida_registral` varchar(100) DEFAULT NULL,
  `modalidad_servicio` varchar(255) DEFAULT NULL,
  `documento_sustento` varchar(100) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tarjetas_circulacion`
--

INSERT INTO `tarjetas_circulacion` (`id`, `vehiculo_id`, `numero`, `vigente_desde`, `vigente_hasta`, `razon_social`, `ruc`, `partida_registral`, `modalidad_servicio`, `documento_sustento`, `estado`, `observaciones`, `creado_en`, `actualizado_en`) VALUES
(26, 7, '15P26003090E', '2026-04-20', '2035-02-03', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(27, 41, '15P24004557E', '2024-06-28', '2028-07-07', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(28, 37, '15P25000936E', '2025-02-05', '2030-12-31', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(29, 8, '15P25009727E', '2025-12-02', '2034-07-01', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(30, 23, '15P24004554E', '2024-06-28', '2028-07-05', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(31, 13, '15P22008485E', '2022-12-13', '2029-12-10', 'EMPRESA DE TRANSPORTES TICLLAS SAC - ET TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(32, 11, '15P24009032E', '2024-12-16', '2028-11-14', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(33, 22, '15P22007996E', '2022-11-22', '2029-12-15', 'EMPRESA DE TRANSPORTES TICLLAS SAC - ET TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(34, 28, '15P22002183E', '2025-02-05', '2034-12-31', NULL, NULL, NULL, NULL, NULL, 'VENCIDO', NULL, '2026-09-18 15:09:09', '2026-09-19 16:04:50'),
(35, 12, '15P25004483E', '2025-06-16', '2035-06-10', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(36, 32, '15P24009031E', '2024-12-16', '2028-11-14', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(37, 15, '15P25000935E', '2025-02-05', '2034-12-31', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(38, 24, '15P24008909E', '2024-12-12', '2028-11-14', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(39, 39, '15P26004505E', '2026-01-20', '2029-07-20', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(40, 16, '15P24004553E', '2024-06-28', '2028-07-07', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(41, 14, '15P24009033E', '2024-12-16', '2028-11-14', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(42, 20, '15P26005040E', '2026-07-07', '2035-07-07', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(43, 25, '15P24004760E', '2024-05-07', '2032-07-11', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(44, 33, '15P25005281E', '2024-07-24', '2028-06-13', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(45, 35, '15P24009035E', '2024-12-16', '2028-11-14', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(46, 27, '15P25009570E', '2025-11-26', '2027-12-31', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(47, 6, '15P26003617E', NULL, '2033-08-14', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(48, 10, '15P24004555E', '2024-06-28', '2028-07-07', 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '00599PNT', 'TRANSPORTE DE PASAJEROS NACIONAL TURISTICO', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:09', '2026-09-18 15:09:09'),
(49, 38, '15P23004521E', '2023-04-08', '2032-07-01', 'EMPRESA DE TRANSPORTES TICLLAS SAC - ET TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, 'VIGENTE', NULL, '2026-09-18 15:09:10', '2026-09-18 15:09:10'),
(50, 3, '15P26005018E', '2026-02-27', NULL, 'EMPRESA DE TRANSPORTES TICLLAS SAC', '20443848778', '000435PNR', 'TRANSPORTE DE PASAJEROS NACIONAL REGULAR', NULL, NULL, NULL, '2026-09-18 15:09:10', '2026-09-18 15:09:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `rol_id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `usuario` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `estado` enum('ACTIVO','INACTIVO') NOT NULL DEFAULT 'ACTIVO',
  `ultimo_acceso` datetime DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `rol_id`, `nombre`, `usuario`, `password_hash`, `estado`, `ultimo_acceso`, `creado_en`, `actualizado_en`) VALUES
(1, 1, 'Administrador', 'admin', '$2y$12$/c0zUKCLM.haaS776t8u2.MnEpiZzeO5JLAaXMXJZhZlSTQdy.9uG', 'ACTIVO', '2026-10-14 09:20:13', '2026-10-05 14:58:06', '2026-10-14 16:20:13'),
(2, 2, 'Usuario1', 'mayumi', '$2y$12$fu5HcfKP9Vm7knV0JPlCge.mxS3SuvN4Jdq9rLjSYmaCV9//fbQcq', 'ACTIVO', '2026-10-14 09:21:23', '2026-10-14 16:21:06', '2026-10-14 16:21:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

CREATE TABLE `vehiculos` (
  `id` int(10) UNSIGNED NOT NULL,
  `socio_id` int(10) UNSIGNED DEFAULT NULL,
  `responsable_id` int(10) UNSIGNED DEFAULT NULL,
  `placa` varchar(10) NOT NULL,
  `marca` varchar(80) DEFAULT NULL,
  `modelo` varchar(80) DEFAULT NULL,
  `clase` varchar(80) DEFAULT NULL,
  `carroceria` varchar(100) DEFAULT NULL,
  `anio` smallint(5) UNSIGNED DEFAULT NULL,
  `numero_asientos` smallint(5) UNSIGNED DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vehiculos`
--

INSERT INTO `vehiculos` (`id`, `socio_id`, `responsable_id`, `placa`, `marca`, `modelo`, `clase`, `carroceria`, `anio`, `numero_asientos`, `creado_en`) VALUES
(1, 1, 1, 'F6R-964', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 17:46:31'),
(2, 1, 1, 'C1M-957', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 17:50:00'),
(3, 1, 1, 'D2T-950', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:12:57'),
(4, 1, 1, 'D8J-954', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:21:19'),
(5, 1, 1, 'CPG-667', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:24:48'),
(6, 1, 1, 'W5N-638', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:27:34'),
(7, 7, 7, 'BYE-106', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:30:47'),
(8, 7, 7, 'D4E-952', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:33:56'),
(9, 7, 7, 'C6R-963', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:35:28'),
(10, 7, 7, 'CMD-440', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:36:41'),
(11, 7, 7, 'CPJ-252', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:38:12'),
(12, 7, 12, 'T9A-965', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:39:29'),
(13, 7, 12, 'D9F-961', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:40:31'),
(14, 7, 12, 'CPJ-497', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:41:27'),
(15, 15, 15, 'C8E-958', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:43:04'),
(16, 15, 15, 'CMD-189', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:43:54'),
(17, 15, 15, 'W5W-204', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:44:56'),
(18, 15, 19, 'F3S-955', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:46:37'),
(19, 15, 19, 'B8X-969', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:47:24'),
(20, 21, 21, 'F4A-950', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:48:55'),
(21, 21, 21, 'C3M-954', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:49:40'),
(22, 21, 21, 'Z3K-502', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:50:29'),
(23, 21, 21, 'CMD-429', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:51:25'),
(24, 21, 21, 'CPH-367', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:52:13'),
(25, 26, 26, 'V5W-958', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:53:02'),
(26, 26, 26, 'B7C-958', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:55:00'),
(27, 26, 26, 'B0A-954', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:56:19'),
(28, 26, 26, 'C8E-952', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:57:12'),
(29, 26, 26, 'B1H-967', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:58:11'),
(30, 26, 26, 'W5M-281', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 20:59:25'),
(31, 26, 26, 'W5U-035', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:00:21'),
(32, 26, 33, 'CPI-465', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:02:14'),
(33, 35, 34, 'W5M-352', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:03:33'),
(34, 35, 35, 'W5W-561', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:04:58'),
(35, 35, 35, 'CPJ-640', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:05:48'),
(36, 35, 37, 'F5N-964', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:06:39'),
(37, 35, 37, 'VBS-967', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:07:37'),
(38, 35, 37, 'V0A-956', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:08:24'),
(39, 35, 37, 'D4Y-965', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:09:12'),
(40, 35, 37, 'B7E-700', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:09:57'),
(41, 35, 37, 'CMD-540', NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-07 21:10:45');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `concesiones_rutas`
--
ALTER TABLE `concesiones_rutas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_cr_vehiculo` (`vehiculo_id`),
  ADD KEY `idx_cr_ruta` (`ruta_id`),
  ADD KEY `idx_cr_vencimiento` (`vigente_hasta`);

--
-- Indices de la tabla `responsables`
--
ALTER TABLE `responsables`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_responsable_socio` (`socio_id`,`nombre`),
  ADD KEY `idx_responsables_socio` (`socio_id`);

--
-- Indices de la tabla `revisiones_tecnicas`
--
ALTER TABLE `revisiones_tecnicas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_rt_vehiculo` (`vehiculo_id`),
  ADD KEY `idx_rt_vencimiento` (`vigente_hasta`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `rutas`
--
ALTER TABLE `rutas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ruta_nombre` (`nombre`),
  ADD KEY `idx_rutas_vencimiento` (`fecha_vencimiento`);

--
-- Indices de la tabla `seguros`
--
ALTER TABLE `seguros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_seguros_vehiculo` (`vehiculo_id`),
  ADD KEY `idx_seguros_vigencia` (`vigente_hasta`);

--
-- Indices de la tabla `seguro_pagos`
--
ALTER TABLE `seguro_pagos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_seguro_pagos_seguro` (`seguro_id`),
  ADD KEY `idx_seguro_pagos_fecha` (`fecha_pago`);

--
-- Indices de la tabla `soats`
--
ALTER TABLE `soats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_soat_vehiculo` (`vehiculo_id`),
  ADD KEY `idx_soat_vencimiento` (`vigente_hasta`);

--
-- Indices de la tabla `soat_pagos`
--
ALTER TABLE `soat_pagos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_soat_pagos_soat` (`soat_id`),
  ADD KEY `idx_soat_pagos_fecha` (`fecha_pago`);

--
-- Indices de la tabla `socios`
--
ALTER TABLE `socios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_socios_nombre` (`nombre`);

--
-- Indices de la tabla `tarjetas_circulacion`
--
ALTER TABLE `tarjetas_circulacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tc_vehiculo` (`vehiculo_id`),
  ADD KEY `idx_tc_vencimiento` (`vigente_hasta`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD KEY `idx_usuarios_rol` (`rol_id`);

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_vehiculo_placa` (`placa`),
  ADD KEY `idx_vehiculos_socio` (`socio_id`),
  ADD KEY `idx_vehiculos_responsable` (`responsable_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `concesiones_rutas`
--
ALTER TABLE `concesiones_rutas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `responsables`
--
ALTER TABLE `responsables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT de la tabla `revisiones_tecnicas`
--
ALTER TABLE `revisiones_tecnicas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `rutas`
--
ALTER TABLE `rutas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `seguros`
--
ALTER TABLE `seguros`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `seguro_pagos`
--
ALTER TABLE `seguro_pagos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `soats`
--
ALTER TABLE `soats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de la tabla `soat_pagos`
--
ALTER TABLE `soat_pagos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `socios`
--
ALTER TABLE `socios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT de la tabla `tarjetas_circulacion`
--
ALTER TABLE `tarjetas_circulacion`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `concesiones_rutas`
--
ALTER TABLE `concesiones_rutas`
  ADD CONSTRAINT `fk_cr_ruta` FOREIGN KEY (`ruta_id`) REFERENCES `rutas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cr_vehiculo` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `responsables`
--
ALTER TABLE `responsables`
  ADD CONSTRAINT `fk_responsables_socio` FOREIGN KEY (`socio_id`) REFERENCES `socios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `revisiones_tecnicas`
--
ALTER TABLE `revisiones_tecnicas`
  ADD CONSTRAINT `fk_rt_vehiculo` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `seguros`
--
ALTER TABLE `seguros`
  ADD CONSTRAINT `fk_seguros_vehiculo` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `seguro_pagos`
--
ALTER TABLE `seguro_pagos`
  ADD CONSTRAINT `fk_seguro_pagos_seguro` FOREIGN KEY (`seguro_id`) REFERENCES `seguros` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `soats`
--
ALTER TABLE `soats`
  ADD CONSTRAINT `fk_soat_vehiculo` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `soat_pagos`
--
ALTER TABLE `soat_pagos`
  ADD CONSTRAINT `fk_soat_pagos_soat` FOREIGN KEY (`soat_id`) REFERENCES `soats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tarjetas_circulacion`
--
ALTER TABLE `tarjetas_circulacion`
  ADD CONSTRAINT `fk_tc_vehiculo` FOREIGN KEY (`vehiculo_id`) REFERENCES `vehiculos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuarios_rol` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`);

--
-- Filtros para la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD CONSTRAINT `fk_vehiculos_responsable` FOREIGN KEY (`responsable_id`) REFERENCES `responsables` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_vehiculos_socio` FOREIGN KEY (`socio_id`) REFERENCES `socios` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
